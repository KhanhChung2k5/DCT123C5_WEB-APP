Kính gửi Thầy Hoàng Mạnh Hà,

Em xin gửi đến Thầy bài nộp cho học phần web1-App, được thực hiện bởi Nhóm LTW01_T3-03(Phát truyển giao diện website bán tay cầm chơi game). Em hy vọng bài làm này sẽ đáp ứng được yêu cầu của bài tập và rất mong nhận được sự góp ý từ Thầy.

Trân trọng,
Nguyễn Quốc Huy, Nguyễn Minh Khoa, Hoàng Hải, Chung Hoàng Công Khanh.
Sau đây là phần trình bày trang web.
    -Đầu tiên là trang web chính(trang chủ Shop.html) có header, trong header có menu chuyển hướng trang, giao diện tìm kiếm sản phẩm(ui, ux) chức năng đăng kí và đăng nhập, có thể hoạt động trơn chủ và mượt mà, với chức năng đăng kí và đăng nhập nhóm em đã làm cho thật nhất có thể, có thể tạo tài khoản và đăng nhập dựa trên tài khoản đã tạo, chức năng bắt buộc phải đăng nhập mới có thể mua hàng, để xem chi tiết món hàng chỉ cần nhấn vào hình ảnh sản phẩm sẽ dẫn đến trang sản phẩm đó, do thời gian có hạn nên hiện tại nhóm chỉ xây duy nhất 1 sản phẩm chi tiết, khi người dùng muốn mua hàng hay bỏ vào giỏ hàng thì chỉ cần nhấn vào sản phẩm thì trong giỏ hàng sẽ có sản phẩm đó ở 
    +Ở mục giỏ hàng thầy nhập mã giảm giá là "Thayhadeptrai" sẽ được giảm giá 30% tổng giỏ hàng, ở giỏ hàng có thể xóa được mặt hàng, khi nhấn vào đi đến thanh toán
    +Đi đến thanh toán sẽ có preview về hóa đơn, xem lại đơn hàng, giá tiền toàn bộ sản phẩm, phí... nhập lại thông tin giao hàng sdt... quan trọng nhất là mục thẻ ngân hàng.

    việc có thể lấy dữ liệu từ các trang trước là vì nhóm em đã dùng 1 kĩ thuật là scene transition có nghĩa là em dùng các div có rộng và cao toàn màn hình và đồng thời ẩn đi các scene cũ bằng display:"none" hoàn toàn không dùng đến dữ liệu bên ngoài(data)
    Với các trang chuyển hướng khác do vấn đề về xung đột các scene nên nhóm quyết định chuyển trang và các giỏ hàng cũ buộc phải bỏ qua.
    
    -Phía dưới header là banner1 banner tĩnh
    -Tiếp theo là flash sale trong là mục đặc biệt giảm giá tức thì trong thời gian có hạn
    -Tiêp theo là banner2 là banner động có thể chuyển banner, em dùng js và học cách làm trên trang w3school.com, youtube...
    -Tiếp theo là danh mục các sản phẩm được xử lý bằng js là chính, cách này được nhóm lên ý tưởng để tránh việc hardcode việc của nhóm muốn thêm sản phẩm chỉ là dùng js và thêm vào 1 obj mới 
    -Cuối cùng là footer.
    Ở menu có các trang chuyển hướng đầu tiên là Trang chủ là tran chính, Sản phẩm là toàn bộ sản phẩm.

    Toàn bộ sản phẩm(Allproduct.html) là trang chứa toàn bộ sản phẩm, có thanh tìm kiếm, account, cart chỉ dừng lại ở (ui, ux)
    -Bộ lọc có thể lọc được sản phẩm theo danh mục là game, ps5, xbox
    -Sản phẩm được tạo bởi js.

    Tiếp là trang admin: trang điều chỉnh về 
